using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo5
{
    public class MathUtilities
    {
        // static method
        public static int Square(int number)
        {
            return number * number;
        }
    }
}